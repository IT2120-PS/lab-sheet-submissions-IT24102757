getwd()
setwd("C:\\Users\\Gimhani\\Desktop\\IT24102757")

#Import the dataset
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)

#Calculate the population mean of laptop bag weights
popmn <- mean(Weight.kg.)

#Calculate the population variance
popvar <- var(Weight.kg.)

popmn
popvar


#Initialize empty containers for samples and sample names
samples <- c()
n <- c()

#Loop to draw 25 samples of size 6 with replacement
for(i in 1:25) {
  s <- sample(Weight.kg.,6,replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste("s" , i ))
}

#Assign column names into sample matrix
colnames(samples) <- n

#Calculate the sample mean and sample variances
s.means <- apply(samples, 2, mean)
s.vars <- apply(samples, 2, var)

s.means
s.vars

# Mean of 25 sample mean
samplesmean <- mean(s.means)

# Variance of 25 sample mean
samplevars <- var(s.means)

popmn
samplesmean

# Sample size = 6
truevar <- popvar / 6

samplevars
truevar












