#Q1
setwd("C:\\Users\\IT24102757\\Desktop\\IT24102757")
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main = "Sales Distribution", outliine = "Sales", col = "Yellow")

#Q4
summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)


#Q5
find_outliers <- function(x)
{
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  
  outliers <- x[x < lower | x > upper]
  return (outliers)
}

find_outliers(branch_data$Years_X3) 








