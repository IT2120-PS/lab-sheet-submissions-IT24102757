getwd()
setwd("C:\\Users\\Gimhani\\Desktop\\IT24102757")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")

names(Delivery_Times) <- c("DeliverTimes")
attach(Delivery_Times)
histogram <- hist(DeliverTimes, main ="Histogram for Delivery Times",
                  breaks = seq(20,70,length = 10), right = FALSE)


#The distribution is roughly symmetric and looks like a bell-shaed curve.


breaks <- round(histogram$breaks)

freq <- histogram$counts

mids <- histogram$mids

classes <- c()

cbind(classes = classes, frequency =freq)

lines(mids, freq)

cum.freq <- cumsum(freq)

new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }
  else{
    new[i]=cum.freq[i-1]
  }
}


plot(breaks, new, type = 'l', main = "Cumulative frequency polygon for Delivery Times",
     xlab = "DeliverTimes", ylab = "Cumulative Frequency", ylim = c(0,max(cum.freq)))

cbind(UpperLimit = breaks, cumulativeFrequency = new)
